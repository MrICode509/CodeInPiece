// Traitement formulaire s'inscrire au cours

const submitHandler = (event) => {
	event.preventDefault();

	let inputs = document.querySelectorAll("input");

	inputs.forEach(input => {
		let error = validateField(input);
	})
}

const validateField = (input) => {
	const { value } = input;
	let error = [];

	if (!value || value.length < 1) {
		error.push(' Champs obligatoire');
	}

	let displayBox = input.nextElementSibling;

	displayBox.innerHTML = "";
	if(error.length > 0) {
		error.forEach(er => displayBox.innerHTML += er)
		displayBox.style.display = "inline-block";
	}else {
		displayBox.style.display = "none";
	}
}

const updateField = (event) => {
	let error = validateField(event.target)
}

document.getElementById('forms').addEventListener('submit', submitHandler);

let inputs = document.querySelectorAll("input");
inputs.forEach(input => {
	input.addEventListener('input', updateField, false)
})

// btn menu Show or Hide

function showMenu() {
	if(document.getElementById("nav-menu").style.display == "block") {
		document.getElementById("nav-menu").style.display ="none";
	}
	else{
		document.getElementById("nav-menu").style.display ="block";
	}
}